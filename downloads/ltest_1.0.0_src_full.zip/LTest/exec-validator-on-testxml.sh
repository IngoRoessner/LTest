#!/bin/bash

java -cp resources/xsd-validator/ ValidateAgainstXsd $1 $2
